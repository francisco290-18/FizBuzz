﻿using System;
using Fran.FizBuzz.Helper;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;

namespace Fran.FizBuzz.Test
{
    [TestClass]
    public class Step03Tests
    {
        private Helper.FizBuzz fiz;

        [TestInitialize]
        public void Setup()
        {
            var rules = new List<IRule>
            {
                new LuckyRule(),
                new FizzBuzzMod3and5Rule(),
                new FizzMod3Rule(),
                new BuzzMod5Rule()
            };

            fiz = new Helper.FizBuzz(rules);
        }

        [TestMethod]
        public void Test1to20()
        {
            string input = fiz.Start(1, 20);
            string testResult = "- fizz: 4 \r\n- buzz: 3 \r\n- fizzbuzz: 1\r\n- lucky: 2 \r\n- number: 10";
            Assert.AreEqual(testResult, fiz.Reporting(input));
        }

        [TestMethod]
        public void Test1to1()
        {
            string input = fiz.Start(1, 1);
            string testResult = "- fizz: 0 \r\n- buzz: 0 \r\n- fizzbuzz: 0\r\n- lucky: 0 \r\n- number: 1";
            Assert.AreEqual(testResult, fiz.Reporting(input));
        }
    }
}