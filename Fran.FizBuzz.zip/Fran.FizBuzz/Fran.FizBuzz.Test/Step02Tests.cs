﻿using System;
using Fran.FizBuzz.Helper;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;

namespace Fran.FizBuzz.Test
{
    [TestClass]
    public class Step02Tests
    {
        private Helper.FizBuzz fiz;

        [TestInitialize]
        public void Setup()
        {
            var rules = new List<IRule>
            {
                new LuckyRule(),
                new FizzBuzzMod3and5Rule(),
                new FizzMod3Rule(),
                new BuzzMod5Rule()
            };

            fiz = new Helper.FizBuzz(rules);
        }

        [TestMethod]
        public void TestOutput()
        {
            string testResult = "1 2 lucky 4 buzz fizz 7 8 fizz buzz 11 fizz lucky 14 fizzbuzz 16 17 fizz 19 buzz";
            Assert.AreEqual(testResult, fiz.Start(1, 20));
        }

    }
}