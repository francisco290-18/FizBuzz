﻿using System;
using System.Collections.Generic;
using System.Text;
using Fran.FizBuzz.Helper;

namespace Fran.FizBuzz
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Fran's FizBuzz Attempt!!!!";
            Console.WriteLine("I have already hard Coded Start Range and End Range 1-20");

            var rules = new List<IRule>
            {
                new LuckyRule(),
                new FizzBuzzMod3and5Rule(),
                new FizzMod3Rule(),
                new BuzzMod5Rule()
            };

            //Change the Range if needed
            string result = new Helper.FizBuzz(rules).Start(1, 20);
            string reportingResult = new Helper.FizBuzz(rules).Reporting(result);
            Console.WriteLine(result);
            Console.WriteLine(reportingResult);
            Console.ReadKey();
        }
    }
}