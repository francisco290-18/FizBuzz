﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Collections.ObjectModel;


namespace Fran.FizBuzz.Helper
{
    public class FizBuzz
    {
        private List<IRule> _rules;
        private StringBuilder _consoleOutput = new StringBuilder();
        private StringBuilder _consoleReportingOutput = new StringBuilder();

        public FizBuzz(List<IRule> rules)
        {
            _rules = rules ?? new List<IRule>();
        }

        public string Start(int startRange, int endRange)
        {
            for (var i = startRange; i <= endRange; i++)
            {
                var output = string.Empty;
                foreach (var rule in _rules)
                {
                    output += rule.Run(i);
                    if (output != string.Empty)
                        break;
                }
                if (output == string.Empty)
                {
                    output += new EmptyRule().Run(i);
                }
                _consoleOutput.Append(output + " ");
            }
            return _consoleOutput.ToString().Trim();
        }

        public string Reporting(string fizzBuzzOutput)
        {
            string[] words = fizzBuzzOutput.Split(new[] { " " }, StringSplitOptions.RemoveEmptyEntries);
            int fizzCount = 0;
            int buzzCount = 0;
            int fizzbuzzCount = 0;
            int luckyCount = 0;
            int numCount = 0;

            Dictionary<string, int> statistics = words
                .GroupBy(word => word)
                .ToDictionary(
                    kvp => kvp.Key,
                    kvp => kvp.Count());

            if(statistics.ContainsKey("fizz"))
                fizzCount = statistics["fizz"];
            if (statistics.ContainsKey("buzz"))
                buzzCount = statistics["buzz"];
            if (statistics.ContainsKey("fizzbuzz"))
                fizzbuzzCount = statistics["fizzbuzz"];
            if (statistics.ContainsKey("lucky"))
                luckyCount = statistics["lucky"];
            numCount = words.Length - fizzCount - buzzCount - fizzbuzzCount - luckyCount;

            return String.Format("- fizz: {0} \r\n- buzz: {1} \r\n- fizzbuzz: {2}\r\n- lucky: {3} \r\n- number: {4}", fizzCount, buzzCount, fizzbuzzCount, luckyCount, numCount); ;
        }
    }
}