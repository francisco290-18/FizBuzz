﻿namespace Fran.FizBuzz.Helper
{
    public interface IRule
    {
        string Run(double number);
    }

    public class LuckyRule : IRule
    {
        public string Run(double number)
        {
            return (number.ToString().Contains("3")) ? "lucky" : string.Empty;
        }
    }

    public class FizzMod3Rule : IRule
    {
        public string Run(double number)
        {
            return ((number % 3) == 0) && !((number % 5) == 0) ? "fizz" : string.Empty;
        }
    }

    public class BuzzMod5Rule : IRule
    {
        public string Run(double number)
        {
            return ((number % 5) == 0) && !((number % 3) == 0) ? "buzz" : string.Empty;
        }
    }

    public class FizzBuzzMod3and5Rule : IRule
    {
        public string Run(double number)
        {
            return ((number % 3) == 0) && ((number % 5) == 0) ? "fizzbuzz" : string.Empty;
        }
    }

    public class EmptyRule : IRule
    {
        public string Run(double number)
        {
            return number.ToString();
        }
    }
}